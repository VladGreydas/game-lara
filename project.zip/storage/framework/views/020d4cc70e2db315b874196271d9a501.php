<section>
    <div class="p-6 ml-5 flex-col">
        <?php $locomotive = $train->locomotive;?>
        <h3 class="p-5 font-semibold text-xl text-gray-800 leading-tight">
            Locomotive
        </h3>
        <div class="p-6 flex-col">
            <div class="flex">
                <p class="pt-2 pr-2 text-lg text-gray-900">Name:             <?php echo e($locomotive->name); ?></p>
                <?php if (isset($component)) { $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02 = $attributes; } ?>
<?php $component = App\View\Components\Rename::resolve(['name' => 'locomotive','id' => ''.e($locomotive->id).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rename'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Rename::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $attributes = $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $component = $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
            </div>
            <p class="mt-4 text-lg text-gray-900">Level:            <?php echo e($locomotive->lvl); ?></p>
            <p class="mt-4 text-lg text-gray-900">Weight:           <?php echo e($locomotive->weight); ?>t</p>
            <p class="mt-4 text-lg text-gray-900">Type:             <?php echo e($locomotive->type); ?></p>
            <p class="mt-4 text-lg text-gray-900">Power:            <?php echo e($locomotive->power); ?>hp</p>
            <p class="mt-4 text-lg text-gray-900">Wagon Capacity:   <?php echo e(count($train->wagons)); ?> / <?php echo e($locomotive->getWagonCap()); ?></p>
            <p class="mt-4 text-lg text-gray-900">Armor:            <?php echo e($locomotive->armor); ?> / <?php echo e($locomotive->max_armor); ?></p>
            <p class="mt-4 text-lg text-gray-900">Fuel:             <?php echo e($locomotive->fuel); ?> / <?php echo e($locomotive->max_fuel); ?></p>
        </div>
    </div>
</section>
<?php /**PATH /var/www/game.local/resources/views/player/partials/locomotive-info.blade.php ENDPATH**/ ?>