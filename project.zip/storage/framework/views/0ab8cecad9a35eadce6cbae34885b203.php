<section>
    <div class="flex">
        <p class="pt-2 pr-2 text-lg text-gray-900">Name:             <?php echo e($wagon->name); ?></p>
        <?php if (isset($component)) { $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02 = $attributes; } ?>
<?php $component = App\View\Components\Rename::resolve(['name' => 'wagon','id' => ''.e($wagon->id).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rename'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Rename::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $attributes = $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $component = $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
    </div>
    <p class="mt-4 text-lg text-gray-900">Level:            <?php echo e($wagon->lvl); ?></p>
    <p class="mt-4 text-lg text-gray-900">Weight:           <?php echo e($wagon->weight); ?>t</p>
    <p class="mt-4 text-lg text-gray-900">Armor:            <?php echo e($wagon->armor); ?> / <?php echo e($wagon->max_armor); ?></p>
    <p class="mt-4 text-lg text-gray-900">Type:             <?php echo e($type); ?></p>
</section>
<?php /**PATH /var/www/game.local/resources/views/player/partials/wagon-info.blade.php ENDPATH**/ ?>