<section>
    <div class="mt-6 ml-64 mr-64 bg-white shadow-sm rounded-lg divide-y"> 
        <div class="p-6 flex-col">
            <p class="mt-4 text-lg text-gray-900">Nickname:     <?php echo e($player->nickname); ?></p>
            <p class="mt-4 text-lg text-gray-900">Level:        <?php echo e($player->lvl); ?></p>
            <p class="mt-4 text-lg text-gray-900">Cash:         <?php echo e($player->money); ?></p>
            <p class="mt-4 text-lg text-gray-900">EXP:          <?php echo e($player->exp); ?> / <?php echo e($player->max_exp); ?></p>
            <p class="mt-4 text-lg text-gray-900">Current Town: <?php echo e($player->town->name); ?></p>

            <?php if( $player->exp >= $player->max_exp ): ?>
                <div class="mt-6 shadow-sm rounded-lg divide-y">
                    <form method="POST" action="<?php echo e(route('player.update', $player)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="lvl" value="<?php echo e($player->lvl+1); ?>">
                        <input type="hidden" name="exp" value="<?php echo e($player->exp - $player->max_exp); ?>">
                        <input type="hidden" name="max_exp" value="<?php echo e($player->max_exp * 1.75); ?>">
                        <input type="hidden" name="money" value="<?php echo e($player->money+=500); ?>">
                        <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ml-1 h-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-1 h-12']); ?><?php echo e(__('LEVEL UP!')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH /var/www/game.local/resources/views/player/partials/player-info.blade.php ENDPATH**/ ?>