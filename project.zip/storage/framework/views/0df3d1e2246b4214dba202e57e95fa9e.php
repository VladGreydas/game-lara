<?php if (isset($component)) { $__componentOriginald73677f70f563e9b0db6070e9aea6576 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald73677f70f563e9b0db6070e9aea6576 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-group','data' => ['name' => 'town-info','color' => 'black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'town-info','color' => 'black']); ?>
     <?php $__env->slot('headings', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'station','label' => 'Station','active' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'station','label' => 'Station','active' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
        <?php if($town->workshop): ?>
            <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'workshop','label' => 'Workshop']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'workshop','label' => 'Workshop']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($town->rail_shop): ?>
            <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'rail_shop','label' => 'Rail shop']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'rail_shop','label' => 'Rail shop']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($town->shop): ?>
            <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'shop','label' => 'Shop']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shop','label' => 'Shop']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginalb705a984512d26a5581848182038e9df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb705a984512d26a5581848182038e9df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-body','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'station','active' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'station','active' => 'true']); ?>
            <?php echo $__env->make('town.partials.station', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
        <?php if($town->workshop): ?>
            <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'workshop']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'workshop']); ?>
                <?php echo $__env->make('town.partials.workshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($town->rail_shop): ?>
            <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'rail_shop']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'rail_shop']); ?>
                <?php echo $__env->make('town.partials.rail_shop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $attributes = $__attributesOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__attributesOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $component = $__componentOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__componentOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $attributes = $__attributesOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__attributesOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $component = $__componentOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__componentOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php /**PATH /var/www/game.local/resources/views/town/partials/town-tabs.blade.php ENDPATH**/ ?>