<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([ 
    'name' => '' ,
    'headings' => '',
    'color' => 'blue'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([ 
    'name' => '' ,
    'headings' => '',
    'color' => 'blue'
]); ?>
<?php foreach (array_filter(([ 
    'name' => '' ,
    'headings' => '',
    'color' => 'blue'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php 
    $name = preg_replace('/[\s]/', '-', $name);
    if ($name == '') die('you need to specify the name property of the tab');
?>
<div class="border-b border-gray-200 dark:border-gray-700 bw-tab bw-tab-<?php echo e($name); ?>">
    <ul class="flex flex-wrap -mb-px tab <?php echo e($name); ?>-headings" data-name="<?php echo e($name); ?>">
        <?php echo e($headings); ?>

    </ul>
</div>
<?php echo e($slot); ?><?php /**PATH /var/www/game.local/resources/views/components/bladewind/tab-group.blade.php ENDPATH**/ ?>