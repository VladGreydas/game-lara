<?php foreach (([ 'name' => 'tab']) as $__key => $__value) {
    $__consumeVariable = is_string($__key) ? $__key : $__value;
    $$__consumeVariable = is_string($__key) ? $__env->getConsumableComponentData($__key, $__value) : $__env->getConsumableComponentData($__value);
} ?>
<?php $name = preg_replace('/[\s-]/', '_', $name); ?>
<div class="<?php echo e($name); ?>-tab-contents" data-name="<?php echo e($name); ?>">
    <?php echo e($slot); ?>

</div><?php /**PATH /var/www/game.local/resources/views/components/bladewind/tab-body.blade.php ENDPATH**/ ?>