<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name' => defaultBladewindName(),
    'value' => null,
    'label' => null,
    'checked' => false,
    'disabled' => false,
    'type' => 'checkbox',
    'class' => 'rounded-md',
    'label_css' => '',
    'color' => config('bladewind.checkbox.color', 'primary'),
    'add_clearing' => config('bladewind.checkbox.add_clearing', true),
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name' => defaultBladewindName(),
    'value' => null,
    'label' => null,
    'checked' => false,
    'disabled' => false,
    'type' => 'checkbox',
    'class' => 'rounded-md',
    'label_css' => '',
    'color' => config('bladewind.checkbox.color', 'primary'),
    'add_clearing' => config('bladewind.checkbox.add_clearing', true),
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    $name = preg_replace('/[\s-]/', '_', $name);
    $checked = parseBladewindVariable($checked);
    $disabled = parseBladewindVariable($disabled);
    $colour = defaultBladewindColour($color);
    $text_colour = ($colour == 'black') ? 'text-black' : "text-$colour-600 dark:bg-dark-800";
    $ring_colour = ($colour == 'black') ? 'ring-black' : "ring-$colour-500";
    $border_colour = ($colour == 'black') ? 'border-slate-500/50' : "border-$colour-500/50";
    $add_clearing = parseBladewindVariable($add_clearing);
?>

<label class="inline-flex items-center cursor-pointer text-sm <?php if($disabled): ?> opacity-60 <?php endif; ?> <?php if($add_clearing): ?> mb-3 <?php endif; ?> <?php echo e($label_css); ?>">
    <input
            type="<?php echo e($type); ?>"
            name="<?php echo e($name); ?>"
            class="<?php echo e($text_colour); ?> size-6 <?php if($add_clearing): ?> mr-2 rtl:ml-2 <?php endif; ?> disabled:opacity-50 focus:<?php echo e($ring_colour); ?> border-2 <?php echo e($border_colour); ?> focus:ring-opacity-25 bw-checkbox <?php echo e($class); ?>"
            <?php if($disabled): ?> disabled <?php endif; ?>
            <?php if($checked): ?> checked <?php endif; ?>
            value="<?php echo e($value); ?>"
    />
    <?php echo $label; ?>

</label>
<?php /**PATH /var/www/game.local/vendor/mkocansey/bladewind/src/../resources/views/components/checkbox.blade.php ENDPATH**/ ?>