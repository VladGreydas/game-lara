<h2 class="font-semibold text-xl text-gray-800 leading-tight">
    <?php echo e(__('Choose what do you want to sell')); ?>

</h2>
<?php if (isset($component)) { $__componentOriginald73677f70f563e9b0db6070e9aea6576 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald73677f70f563e9b0db6070e9aea6576 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-group','data' => ['name' => 'rail_shop_sell','color' => 'black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'rail_shop_sell','color' => 'black']); ?>
     <?php $__env->slot('headings', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'sell-wagon','label' => 'Wagons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sell-wagon','label' => 'Wagons']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'sell-weapon','label' => 'Weapons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sell-weapon','label' => 'Weapons']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginalb705a984512d26a5581848182038e9df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb705a984512d26a5581848182038e9df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-body','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'sell-wagon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sell-wagon']); ?>
            <?php echo $__env->make('town.partials.shop.sell.wagons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'sell-weapon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sell-weapon']); ?>
            <?php echo $__env->make('town.partials.shop.sell.weapons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $attributes = $__attributesOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__attributesOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $component = $__componentOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__componentOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $attributes = $__attributesOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__attributesOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $component = $__componentOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__componentOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php /**PATH /var/www/game.local/resources/views/town/partials/shop/sell.blade.php ENDPATH**/ ?>