<?php $fuel = $player->train->locomotive->max_fuel - $player->train->locomotive->fuel?>
<p class="mt-4 text-lg text-gray-900">Fuel: <?php echo e($player->train->locomotive->fuel); ?> / <?php echo e($player->train->locomotive->max_fuel); ?></p>
<?php if($fuel > 0): ?>
        <?php $cost = ($player->train->locomotive->max_fuel - $player->train->locomotive->fuel) * 5;?>
    <p class="mt-4 text-lg text-gray-900">Refuel cost: <?php echo e($cost); ?></p>
    <form method="post" action="<?php echo e(route('town.refuel')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <input type="hidden" name="player" value="<?php echo e($player->id); ?>">
        <input type="hidden" name="town_id" value="<?php echo e($town->id); ?>">
        <input type="hidden" name="cost" value="<?php echo e($cost); ?>">
        <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ml-1 h-10 mt-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-1 h-10 mt-5']); ?><?php echo e(__('Refuel')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
    </form>
<?php endif; ?>
<?php /**PATH /var/www/game.local/resources/views/town/partials/station.blade.php ENDPATH**/ ?>