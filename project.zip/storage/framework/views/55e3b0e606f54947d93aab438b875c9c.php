<?php
$weapons = \App\Models\Weapon::factory()->makeMultipleShopWeapons();
$iterator = 1;
?>
<script src="<?php echo e(asset('vendor/bladewind/js/helpers.js')); ?>"></script>
<link href="<?php echo e(asset('vendor/bladewind/css/animate.min.css')); ?>" rel="stylesheet"/>

<div class="mt-6 bg-white shadow-sm rounded-lg divide-y w-full">
    <?php if (isset($component)) { $__componentOriginalb1d4134143f55fc997e08cda2165deff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1d4134143f55fc997e08cda2165deff = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.table','data' => ['divider' => 'thin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['divider' => 'thin']); ?>
         <?php $__env->slot('header', null, []); ?> 
            <th class="text-white p-4">Name</th>
            <th class="text-white p-4">Type</th>
            <th class="text-white p-4">Damage</th>
            <th class="text-white p-4">Upgrade Cost</th>
            <th class="text-white p-4">Price</th>
            <th class="text-white p-4">Action</th>
         <?php $__env->endSlot(); ?>
        <?php $__currentLoopData = $weapons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weapon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-slate-800 border-b-2">
                <td class="p-4 font-semibold"><?php echo e($weapon->name); ?></td>
                <td class="text-center"><?php echo e($weapon->type); ?></td>
                <td class="text-center"><?php echo e($weapon->damage); ?></td>
                <td class="text-center"><?php echo e($weapon->upgrade_cost); ?></td>
                <td class="text-center"><?php echo e($weapon->price); ?></td>
                <td class="text-center">
                    <?php if (isset($component)) { $__componentOriginal9a524495f8fba1bb9db48a43313dffc1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9a524495f8fba1bb9db48a43313dffc1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.button.index','data' => ['onclick' => 'showModal(\'action-modal-'.e($iterator).'\')','class' => 'text-white w-9/12 h-full p-2 bg-slate-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'showModal(\'action-modal-'.e($iterator).'\')','class' => 'text-white w-9/12 h-full p-2 bg-slate-800']); ?>
                        <?php echo e(__('Buy')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9a524495f8fba1bb9db48a43313dffc1)): ?>
<?php $attributes = $__attributesOriginal9a524495f8fba1bb9db48a43313dffc1; ?>
<?php unset($__attributesOriginal9a524495f8fba1bb9db48a43313dffc1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a524495f8fba1bb9db48a43313dffc1)): ?>
<?php $component = $__componentOriginal9a524495f8fba1bb9db48a43313dffc1; ?>
<?php unset($__componentOriginal9a524495f8fba1bb9db48a43313dffc1); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal54a4042e8569ecd9303894788710cb73 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal54a4042e8569ecd9303894788710cb73 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.modal','data' => ['backdropCanClose' => 'false','name' => 'action-modal-'.e($iterator).'','okButtonLabel' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['backdrop_can_close' => 'false','name' => 'action-modal-'.e($iterator).'','ok_button_label' => '']); ?>
                        <form method="post" action="<?php echo e(route('weapon.purchase', $player->train)); ?>" class="flex flex-col flex-wrap items-center">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="weapon" value="<?php echo e(json_encode($weapon)); ?>">
                            Choose which wagon to mount <?php echo e($weapon->name); ?> on
                            <?php $__currentLoopData = $player->train->getWeaponWagons(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weapon_wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if (isset($component)) { $__componentOriginal14e3dc0016c2a1bf5aaf83600cacc83e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14e3dc0016c2a1bf5aaf83600cacc83e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.radio-button','data' => ['color' => 'black','name' => 'wagon','label' => ''.e($weapon_wagon->wagon->name).'','value' => ''.e($weapon_wagon->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.radio-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'black','name' => 'wagon','label' => ''.e($weapon_wagon->wagon->name).'','value' => ''.e($weapon_wagon->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14e3dc0016c2a1bf5aaf83600cacc83e)): ?>
<?php $attributes = $__attributesOriginal14e3dc0016c2a1bf5aaf83600cacc83e; ?>
<?php unset($__attributesOriginal14e3dc0016c2a1bf5aaf83600cacc83e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14e3dc0016c2a1bf5aaf83600cacc83e)): ?>
<?php $component = $__componentOriginal14e3dc0016c2a1bf5aaf83600cacc83e; ?>
<?php unset($__componentOriginal14e3dc0016c2a1bf5aaf83600cacc83e); ?>
<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginal9a524495f8fba1bb9db48a43313dffc1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9a524495f8fba1bb9db48a43313dffc1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.button.index','data' => ['canSubmit' => 'true','class' => 'w-9/12 m-2 p-2 h-10 bg-slate-800 text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['can_submit' => 'true','class' => 'w-9/12 m-2 p-2 h-10 bg-slate-800 text-white']); ?>
                                Buy
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9a524495f8fba1bb9db48a43313dffc1)): ?>
<?php $attributes = $__attributesOriginal9a524495f8fba1bb9db48a43313dffc1; ?>
<?php unset($__attributesOriginal9a524495f8fba1bb9db48a43313dffc1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a524495f8fba1bb9db48a43313dffc1)): ?>
<?php $component = $__componentOriginal9a524495f8fba1bb9db48a43313dffc1; ?>
<?php unset($__componentOriginal9a524495f8fba1bb9db48a43313dffc1); ?>
<?php endif; ?>
                        </form>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal54a4042e8569ecd9303894788710cb73)): ?>
<?php $attributes = $__attributesOriginal54a4042e8569ecd9303894788710cb73; ?>
<?php unset($__attributesOriginal54a4042e8569ecd9303894788710cb73); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal54a4042e8569ecd9303894788710cb73)): ?>
<?php $component = $__componentOriginal54a4042e8569ecd9303894788710cb73; ?>
<?php unset($__componentOriginal54a4042e8569ecd9303894788710cb73); ?>
<?php endif; ?>
                </td>
            </tr>
            <?php $iterator++?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1d4134143f55fc997e08cda2165deff)): ?>
<?php $attributes = $__attributesOriginalb1d4134143f55fc997e08cda2165deff; ?>
<?php unset($__attributesOriginalb1d4134143f55fc997e08cda2165deff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1d4134143f55fc997e08cda2165deff)): ?>
<?php $component = $__componentOriginalb1d4134143f55fc997e08cda2165deff; ?>
<?php unset($__componentOriginalb1d4134143f55fc997e08cda2165deff); ?>
<?php endif; ?>
</div>
<?php /**PATH /var/www/game.local/resources/views/town/partials/shop/weapons.blade.php ENDPATH**/ ?>