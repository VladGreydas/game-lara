<div class="mt-4 p-4 border rounded-lg shadow bg-gray-50">
    <div class="flex flex-row pb-1">
        <h3 class="text-lg font-bold m-1 mt-0">🚂 Locomotive: <?php echo e($locomotive->name); ?></h3>
        <?php if (isset($component)) { $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02 = $attributes; } ?>
<?php $component = App\View\Components\Rename::resolve(['type' => 'locomotive','id' => ''.e($locomotive->id).'','name' => ''.e($locomotive->name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rename'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Rename::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $attributes = $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $component = $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
    </div>

    <p><strong>Power:</strong> <?php echo e($locomotive->power); ?></p>
    <p><strong>Armor:</strong> <?php echo e($locomotive->armor); ?> / <?php echo e($locomotive->max_armor); ?></p>
    <p><strong>Fuel:</strong> <?php echo e($locomotive->fuel); ?> / <?php echo e($locomotive->max_fuel); ?></p>
    <p><strong>Level:</strong> <?php echo e($locomotive->lvl); ?></p>
</div>
<?php /**PATH /var/www/game.local/resources/views/components/locomotive-card.blade.php ENDPATH**/ ?>