<?php
    $wagons = \App\Models\Wagon::factory()->makeMultipleShopCargoWagons();
?>
<script src="<?php echo e(asset('vendor/bladewind/js/helpers.js')); ?>"></script>
<link href="<?php echo e(asset('vendor/bladewind/css/animate.min.css')); ?>" rel="stylesheet"/>

<div class="mt-6 bg-white shadow-sm rounded-lg divide-y w-full">
    <?php if (isset($component)) { $__componentOriginalb1d4134143f55fc997e08cda2165deff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1d4134143f55fc997e08cda2165deff = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('header', null, []); ?> 
            <th class="text-white p-4">Name</th>
            <th class="text-white p-4">Weight</th>
            <th class="text-white p-4">Armor</th>
            <th class="text-white p-4">Capacity</th>
            <th class="text-white p-4">Upgrade Cost</th>
            <th class="text-white p-4">Price</th>
            <th class="text-white p-4">Action</th>
         <?php $__env->endSlot(); ?>
        <?php $__currentLoopData = $wagons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="p-4 font-semibold"><?php echo e($wagon['name']); ?></td>
                <td class="text-center"><?php echo e($wagon['weight']); ?>t</td>
                <td class="text-center"><?php echo e($wagon['armor']); ?></td>
                <td class="text-center"><?php echo e($wagon['capacity']); ?></td>
                <td class="text-center"><?php echo e($wagon['upgrade_cost']); ?></td>
                <td class="text-center"><?php echo e($wagon['price']); ?></td>
                <td class="text-center">
                    <form method="post" action="<?php echo e(route('wagon.purchase', $player->train)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="wagon" value="<?php echo e(json_encode($wagon)); ?>">
                        <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'm-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'm-1']); ?><?php echo e(__('Buy')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1d4134143f55fc997e08cda2165deff)): ?>
<?php $attributes = $__attributesOriginalb1d4134143f55fc997e08cda2165deff; ?>
<?php unset($__attributesOriginalb1d4134143f55fc997e08cda2165deff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1d4134143f55fc997e08cda2165deff)): ?>
<?php $component = $__componentOriginalb1d4134143f55fc997e08cda2165deff; ?>
<?php unset($__componentOriginalb1d4134143f55fc997e08cda2165deff); ?>
<?php endif; ?>
</div>
<?php /**PATH /var/www/game.local/resources/views/town/partials/shop/cargo_wagons.blade.php ENDPATH**/ ?>