<h2 class="font-semibold text-xl text-gray-800 leading-tight">
    <?php echo e(__('Choose what do you want to upgrade')); ?>

</h2>
<?php
    foreach ($player->train->wagons as $wagon) {
        if($wagon->wagonable instanceof \App\Models\WeaponWagon && $wagon->wagonable->weapons) {
            $isWeapons = true;
            break;
        }
    }
?>
<?php if (isset($component)) { $__componentOriginald73677f70f563e9b0db6070e9aea6576 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald73677f70f563e9b0db6070e9aea6576 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-group','data' => ['name' => 'workshop','color' => 'black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'workshop','color' => 'black']); ?>
     <?php $__env->slot('headings', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'locomotive','label' => 'Locomotive']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'locomotive','label' => 'Locomotive']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'wagon','label' => 'Wagons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wagon','label' => 'Wagons']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
        <?php if($isWeapons): ?>
            <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'weapon','label' => 'Weapons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'weapon','label' => 'Weapons']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginalb705a984512d26a5581848182038e9df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb705a984512d26a5581848182038e9df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-body','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'locomotive']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'locomotive']); ?>
            <?php echo $__env->make('town.partials.upgrade.locomotive', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'wagon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wagon']); ?>
            <?php if (isset($component)) { $__componentOriginald73677f70f563e9b0db6070e9aea6576 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald73677f70f563e9b0db6070e9aea6576 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-group','data' => ['name' => 'wagons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wagons']); ?>
                 <?php $__env->slot('headings', null, []); ?> 
                    <?php $__currentLoopData = $player->train->wagons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'wagon'.e($wagon->id).'','label' => ''.e($wagon->name).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wagon'.e($wagon->id).'','label' => ''.e($wagon->name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php $__env->endSlot(); ?>
                <?php if (isset($component)) { $__componentOriginalb705a984512d26a5581848182038e9df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb705a984512d26a5581848182038e9df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-body','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php $__currentLoopData = $player->train->wagons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'wagon'.e($wagon->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wagon'.e($wagon->id).'']); ?>
                            <?php echo $__env->make('town.partials.upgrade.wagons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $attributes = $__attributesOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__attributesOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $component = $__componentOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__componentOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $attributes = $__attributesOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__attributesOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $component = $__componentOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__componentOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
        <?php if($isWeapons): ?>
            <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'weapon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'weapon']); ?>
                <?php echo $__env->make('town.partials.upgrade.weapons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $attributes = $__attributesOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__attributesOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $component = $__componentOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__componentOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $attributes = $__attributesOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__attributesOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $component = $__componentOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__componentOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php /**PATH /var/www/game.local/resources/views/town/partials/workshop.blade.php ENDPATH**/ ?>