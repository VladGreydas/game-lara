<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    // available options are true or false as strings.
    // setting this to true will set this tab content as the active one
    'active' => false,
    // unique way to identify this tab content using css or javascript
    // this name is used for switching to this content when the tab header is clicked
    'name' => 'tab'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    // available options are true or false as strings.
    // setting this to true will set this tab content as the active one
    'active' => false,
    // unique way to identify this tab content using css or javascript
    // this name is used for switching to this content when the tab header is clicked
    'name' => 'tab'
]); ?>
<?php foreach (array_filter(([
    // available options are true or false as strings.
    // setting this to true will set this tab content as the active one
    'active' => false,
    // unique way to identify this tab content using css or javascript
    // this name is used for switching to this content when the tab header is clicked
    'name' => 'tab'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php 
    $name = preg_replace('/[\s]/', '-', $name);
    $active = filter_var($active, FILTER_VALIDATE_BOOLEAN);
    $active_css = (!$active) ? 'hidden' : '';
?>
<div class="atab-content bw-tc-<?php echo e($name); ?> <?php echo e($active_css); ?> p-4">
    <?php echo e($slot); ?>

</div><?php /**PATH /var/www/game.local/resources/views/components/bladewind/tab-content.blade.php ENDPATH**/ ?>