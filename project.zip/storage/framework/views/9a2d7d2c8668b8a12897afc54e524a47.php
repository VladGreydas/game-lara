<div class="mt-4 p-4 border rounded-lg shadow bg-gray-50">
    <h3 class="text-lg font-bold mb-2">🚃 Wagons</h3>
    <?php $__currentLoopData = $wagons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-4 p-2 border-b">
            <div class="flex flex-row">
                <p class="m-1"><strong>Wagon: <?php echo e($wagon->name); ?></strong></p>
                <?php if (isset($component)) { $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02 = $attributes; } ?>
<?php $component = App\View\Components\Rename::resolve(['type' => 'wagon','id' => ''.e($wagon->id).'','name' => ''.e($wagon->name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rename'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Rename::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $attributes = $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $component = $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
            </div>
            <ul class="list-disc ml-6">
                <li>Armor: <?php echo e($wagon->armor); ?> / <?php echo e($wagon->max_armor); ?></li>
                <li>Level: <?php echo e($wagon->lvl); ?></li>
                <li>Weight: <?php echo e($wagon->weight); ?></li>
                <?php if($wagon->cargo_wagon): ?>
                    <li>Type: <span class="text-indigo-600">Cargo</span></li>
                    <li>Capacity: <?php echo e($wagon->cargo_wagon->capacity); ?></li>
                <?php endif; ?>

                <?php if($wagon->weapon_wagon): ?>
                    <li>Type: <span class="text-red-600">Weapon</span></li>
                    <?php if (isset($component)) { $__componentOriginal2513d50e984fabc65fff6b82b3269d85 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2513d50e984fabc65fff6b82b3269d85 = $attributes; } ?>
<?php $component = App\View\Components\WeaponList::resolve(['weapons' => $wagon->weapon_wagon->weapons] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('weapon-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\WeaponList::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2513d50e984fabc65fff6b82b3269d85)): ?>
<?php $attributes = $__attributesOriginal2513d50e984fabc65fff6b82b3269d85; ?>
<?php unset($__attributesOriginal2513d50e984fabc65fff6b82b3269d85); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2513d50e984fabc65fff6b82b3269d85)): ?>
<?php $component = $__componentOriginal2513d50e984fabc65fff6b82b3269d85; ?>
<?php unset($__componentOriginal2513d50e984fabc65fff6b82b3269d85); ?>
<?php endif; ?>
                <?php endif; ?>
            </ul>


        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /var/www/game.local/resources/views/components/wagon-list.blade.php ENDPATH**/ ?>