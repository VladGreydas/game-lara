<?php $locomotive = $player->train->locomotive;?>
<h3 class="p-5 font-semibold text-xl text-gray-800 leading-tight">
    Locomotive
</h3>
<div class="p-6 flex-col">
    <p class="mt-4 text-lg text-gray-900">Name:             <?php echo e($locomotive->name); ?></p>
    <p class="mt-4 text-lg text-gray-900">Level:            <?php echo e($locomotive->lvl); ?>(+1)</p>
    <p class="mt-4 text-lg text-gray-900">Weight:           <?php echo e($locomotive->weight); ?> (+<?php echo e(50 * ($locomotive->lvl+1)); ?>)t</p>
    <p class="mt-4 text-lg text-gray-900">Power:            <?php echo e($locomotive->power); ?> (+<?php echo e(500 * ($locomotive->lvl+1)); ?>) hp</p>
    <p class="mt-4 text-lg text-gray-900">Armor:            <?php echo e($locomotive->max_armor); ?> (+<?php echo e(100 * ($locomotive->lvl+1)); ?>)</p>
    <p class="mt-4 text-lg text-gray-900">Fuel:             <?php echo e($locomotive->max_fuel); ?> (+<?php echo e(5 * ($locomotive->lvl+1)); ?>)</p>
    <p class="mt-4 text-lg text-gray-900">Upgrade Cost:     <?php echo e($locomotive->upgrade_cost); ?></p>

    <form method="POST" action="<?php echo e(route('locomotive.upgrade', $locomotive)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="mt-4 space-x-2">
            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('Upgrade')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
        </div>
    </form>
</div>
<?php /**PATH /var/www/game.local/resources/views/town/partials/upgrade/locomotive.blade.php ENDPATH**/ ?>