<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1">
    <p>In Progress</p>
</div>
<?php /**PATH /var/www/game.local/resources/views/town/partials/shop/modal/barter.blade.php ENDPATH**/ ?>