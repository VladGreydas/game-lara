<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([ 
    // to create a radio button group, specify the same name
    // for all the radio buttons in the group
    'name' => 'radio',
    'value' => '',
    'label' => '',
    'label_css' => 'mr-6',
    'labelCss' => 'mr-6',
    'color' => 'blue',
    'checked' => false,
    'class' => '',
    'disabled' => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([ 
    // to create a radio button group, specify the same name
    // for all the radio buttons in the group
    'name' => 'radio',
    'value' => '',
    'label' => '',
    'label_css' => 'mr-6',
    'labelCss' => 'mr-6',
    'color' => 'blue',
    'checked' => false,
    'class' => '',
    'disabled' => false,
]); ?>
<?php foreach (array_filter(([ 
    // to create a radio button group, specify the same name
    // for all the radio buttons in the group
    'name' => 'radio',
    'value' => '',
    'label' => '',
    'label_css' => 'mr-6',
    'labelCss' => 'mr-6',
    'color' => 'blue',
    'checked' => false,
    'class' => '',
    'disabled' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $checked = filter_var($checked, FILTER_VALIDATE_BOOLEAN);
    $disabled = filter_var($disabled, FILTER_VALIDATE_BOOLEAN);
    $label_css = (!empty($labelCss)) ? $labelCss : $label_css;
?>
<?php if (isset($component)) { $__componentOriginal701009bc86ef91af6041f0e4d6588e8f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal701009bc86ef91af6041f0e4d6588e8f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.checkbox','data' => ['name' => ''.e($name).'','label' => ''.e($label).'','value' => ''.e($value).'','color' => ''.e($color).'','class' => 'rounded-full '.e($class).'','labelCss' => ''.e($label_css).'','disabled' => ''.e($disabled).'','checked' => ''.e($checked).'','type' => 'radio']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'','label' => ''.e($label).'','value' => ''.e($value).'','color' => ''.e($color).'','class' => 'rounded-full '.e($class).'','label_css' => ''.e($label_css).'','disabled' => ''.e($disabled).'','checked' => ''.e($checked).'','type' => 'radio']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal701009bc86ef91af6041f0e4d6588e8f)): ?>
<?php $attributes = $__attributesOriginal701009bc86ef91af6041f0e4d6588e8f; ?>
<?php unset($__attributesOriginal701009bc86ef91af6041f0e4d6588e8f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal701009bc86ef91af6041f0e4d6588e8f)): ?>
<?php $component = $__componentOriginal701009bc86ef91af6041f0e4d6588e8f; ?>
<?php unset($__componentOriginal701009bc86ef91af6041f0e4d6588e8f); ?>
<?php endif; ?><?php /**PATH /var/www/game.local/resources/views/components/bladewind/radio-button.blade.php ENDPATH**/ ?>