<?php
    $type = str_replace('App\\Models\\', '', $wagon->wagonable_type);
    $spec = $wagon->wagonable;
?>
<div class="p-6 flex-col">
    <p class="mt-4 text-lg text-gray-900">Name:             <?php echo e($wagon->name); ?></p>
    <p class="mt-4 text-lg text-gray-900">Level:            <?php echo e($wagon->lvl); ?>(+1)</p>
    <?php if($spec instanceof \App\Models\CargoWagon): ?>
        <p class="mt-4 text-lg text-gray-900">Weight:           <?php echo e($wagon->weight); ?> (+<?php echo e(50 * ($wagon->lvl+1)); ?>) t</p>
        <p class="mt-4 text-lg text-gray-900">Armor:            <?php echo e($wagon->max_armor); ?> (+<?php echo e(100 * ($wagon->lvl+1)); ?>)</p>
        <p class="mt-4 text-lg text-gray-900">Capacity:            <?php echo e($spec->capacity); ?> (+<?php echo e(5 * ($wagon->lvl+1)); ?>)</p>
    <?php elseif($spec instanceof \App\Models\WeaponWagon): ?>
        <p class="mt-4 text-lg text-gray-900">Weight:           <?php echo e($wagon->weight); ?> (+<?php echo e(100 * ($wagon->lvl+1)); ?>) t</p>
        <p class="mt-4 text-lg text-gray-900">Armor:            <?php echo e($wagon->max_armor); ?> (+<?php echo e(150 * ($wagon->lvl+1)); ?>)</p>
    <?php endif; ?>
    <p class="mt-4 text-lg text-gray-900">Upgrade Cost:     <?php echo e($wagon->upgrade_cost); ?></p>

    <form method="POST" action="<?php echo e(route('wagon.upgrade', $wagon)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="mt-4 space-x-2">
            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('Upgrade')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
        </div>
    </form>
</div>
<?php /**PATH /var/www/game.local/resources/views/town/partials/upgrade/wagons.blade.php ENDPATH**/ ?>