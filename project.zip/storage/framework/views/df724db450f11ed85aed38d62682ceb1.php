<?php
$wagons = $player->train->wagons;

$cargo = $player->train->getCargoWagons();
$weapon = $player->train->getWeaponWagons();
?>

<h2 class="font-semibold text-xl text-gray-800 leading-tight">
    <?php echo e(__('Choose the wagon')); ?>

</h2>

<?php if (isset($component)) { $__componentOriginald73677f70f563e9b0db6070e9aea6576 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald73677f70f563e9b0db6070e9aea6576 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-group','data' => ['name' => 'rail_shop_sell_wagon','color' => 'black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'rail_shop_sell_wagon','color' => 'black']); ?>
     <?php $__env->slot('headings', null, []); ?> 
        <?php $__currentLoopData = $wagons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'sell-wagon-'.e($wagon->id).'','label' => ''.e($wagon->name).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sell-wagon-'.e($wagon->id).'','label' => ''.e($wagon->name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginalb705a984512d26a5581848182038e9df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb705a984512d26a5581848182038e9df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-body','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php $__currentLoopData = $wagons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'sell-wagon-'.e($wagon->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sell-wagon-'.e($wagon->id).'']); ?>
                <div class="p-6 ml-5 flex-col">
                    <h3 class="p-5 font-semibold text-xl text-gray-800 leading-tight">
                        <?php echo e($wagon->name); ?>

                    </h3>
                    <div class="p-6 flex-col">
                        <p class="mt-4 text-lg text-gray-900">Name: <?php echo e($wagon->name); ?></p>
                        <p class="mt-4 text-lg text-gray-900">Level: <?php echo e($wagon->lvl); ?></p>
                        <p class="mt-4 text-lg text-gray-900">Type: <?php echo e($wagon->getType()); ?></p>
                        <p class="mt-4 text-lg text-gray-900">Price: <?php echo e($wagon->price / 2); ?></p>

                        <?php if (isset($component)) { $__componentOriginal9a524495f8fba1bb9db48a43313dffc1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9a524495f8fba1bb9db48a43313dffc1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.button.index','data' => ['onclick' => 'showModal(\'modal-sell-wagon-'.e($wagon->id).'\')','class' => 'text-white w-2/5 h-full mt-4 p-2 bg-slate-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'showModal(\'modal-sell-wagon-'.e($wagon->id).'\')','class' => 'text-white w-2/5 h-full mt-4 p-2 bg-slate-800']); ?>
                            <?php echo e(__('Sell')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9a524495f8fba1bb9db48a43313dffc1)): ?>
<?php $attributes = $__attributesOriginal9a524495f8fba1bb9db48a43313dffc1; ?>
<?php unset($__attributesOriginal9a524495f8fba1bb9db48a43313dffc1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a524495f8fba1bb9db48a43313dffc1)): ?>
<?php $component = $__componentOriginal9a524495f8fba1bb9db48a43313dffc1; ?>
<?php unset($__componentOriginal9a524495f8fba1bb9db48a43313dffc1); ?>
<?php endif; ?>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal54a4042e8569ecd9303894788710cb73 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal54a4042e8569ecd9303894788710cb73 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.modal','data' => ['backdropCanClose' => 'false','name' => 'modal-sell-wagon-'.e($wagon->id).'','okButtonLabel' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['backdrop_can_close' => 'false','name' => 'modal-sell-wagon-'.e($wagon->id).'','ok_button_label' => '']); ?>
                        <form method="post" action="<?php echo e(route('wagon.sell', $wagon->id)); ?>"
                              class="flex flex-col flex-wrap items-center font-semibold">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            Are you sure you want to sell <?php echo e($wagon->name); ?>?
                            <?php if($wagon->getType() === 'WeaponWagon'): ?>
                                Weapons will be sold too (keeping weapons may be added in the future).
                                <?php if(count($weapon) == 1): ?>
                                    <br/>It's your last weapon wagon in the train. You cannot defend without them. Proceed anyway?
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($wagon->getType() === 'CargoWagon'): ?>
                                All the resources will be transferred into other Cargo wagons (otherwise sold).
                                <?php if(count($cargo) == 1): ?>
                                    <br/>It's your last cargo wagon in the train. You cannot transfer resources without them. Proceed anyway?
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal9a524495f8fba1bb9db48a43313dffc1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9a524495f8fba1bb9db48a43313dffc1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.button.index','data' => ['canSubmit' => 'true','class' => 'w-2/5 m-2 p-2 h-10 bg-slate-800 text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['can_submit' => 'true','class' => 'w-2/5 m-2 p-2 h-10 bg-slate-800 text-white']); ?>
                                Sell
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9a524495f8fba1bb9db48a43313dffc1)): ?>
<?php $attributes = $__attributesOriginal9a524495f8fba1bb9db48a43313dffc1; ?>
<?php unset($__attributesOriginal9a524495f8fba1bb9db48a43313dffc1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a524495f8fba1bb9db48a43313dffc1)): ?>
<?php $component = $__componentOriginal9a524495f8fba1bb9db48a43313dffc1; ?>
<?php unset($__componentOriginal9a524495f8fba1bb9db48a43313dffc1); ?>
<?php endif; ?>
                        </form>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal54a4042e8569ecd9303894788710cb73)): ?>
<?php $attributes = $__attributesOriginal54a4042e8569ecd9303894788710cb73; ?>
<?php unset($__attributesOriginal54a4042e8569ecd9303894788710cb73); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal54a4042e8569ecd9303894788710cb73)): ?>
<?php $component = $__componentOriginal54a4042e8569ecd9303894788710cb73; ?>
<?php unset($__componentOriginal54a4042e8569ecd9303894788710cb73); ?>
<?php endif; ?>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $attributes = $__attributesOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__attributesOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $component = $__componentOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__componentOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $attributes = $__attributesOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__attributesOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $component = $__componentOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__componentOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php /**PATH /var/www/game.local/resources/views/town/partials/shop/sell/wagons.blade.php ENDPATH**/ ?>