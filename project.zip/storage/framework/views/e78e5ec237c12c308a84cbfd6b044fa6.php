<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    // determines types of icon to display. Available options: info, success, error, warning
    // only the blank type (type='') has no icon. useful if you want your modal to contain a form
    // or other custom content
    'type' => '',

    // title text to display. example: Confirm your delete action
    'title' => '',

    // name of the modal. used to uniquely identify the modal in css and js
    'name' => 'bw-modal-'.uniqid(),

    // text to display on the primary button. default is Okay
    'ok_button_label' => 'Okay',
    'okButtonLabel' => 'Okay',

    // text to display on secondary button. default is Cancel
    'cancel_button_label' => 'Cancel',
    'cancelButtonLabel' => 'Cancel',

    // action to perform when secondary button is clicked. default is close.
    // provide a custom js function as string to execute that function. example "saveUser"
    'ok_button_action' => 'close',
    'okButtonAction' => 'close',

    // action to perform when primary button is clicked. default is close.
    // provide a custom js function as a string to execute that function. example "confirmAction"
    'cancel_button_action' => 'close',
    'cancelButtonAction' => 'close',

    // close modal when either primary or close secondary buttons are clicked
    // the modal will be closed after your custom js function has been executed
    'close_after_action' => true,
    'closeAfterAction' => true,

    // determines if clicking on the backdrop can close the modal. default is true
    // when set to false, only the action buttons can close the modal.
    // in this case ensure you have set "close" as an action for one of your action buttons
    'backdrop_can_close' => true,
    'backdropCanClose' => true,

    // should the action buttons be displayed? default is true. false will hide the buttons
    'show_action_buttons' => true,
    'showActionButtons' => true,

    // should the action buttons be centered? default is false. right aligned
    'center_action_buttons' => false,
    'centerActionButtons' => false,

    // should the action buttons stretch the entire width of the modal
    'stretch_action_buttons' => false,
    'stretchActionButtons' => false,

    // should the backdrop of the modal be blurred
    'blur_backdrop' => true,
    'blurBackdrop' => true,

    // determines the size of the modal. available options are small, medium, large and xl
    // on mobile it is small by default but fills up the width of the screen
    'size' => 'big',
    'sizes' => [
        'tiny' => 'w-1/6',
        'small' => 'w-1/5',
        'medium' => 'w-1/4',
        'big' => 'w-1/3',
        'large' => 'w-2/5',
        'xl' => 'w-2/3',
        'omg' => 'w-11/12'
    ],

    // add extra css to the modal body
    'body_css' => '',
    // add extra css to the modal footer
    'footer_css' => '',
    // show close icon. By default, the close or cancel button closes the modal
    'show_close_icon' => false,
    'showCloseIcon' => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    // determines types of icon to display. Available options: info, success, error, warning
    // only the blank type (type='') has no icon. useful if you want your modal to contain a form
    // or other custom content
    'type' => '',

    // title text to display. example: Confirm your delete action
    'title' => '',

    // name of the modal. used to uniquely identify the modal in css and js
    'name' => 'bw-modal-'.uniqid(),

    // text to display on the primary button. default is Okay
    'ok_button_label' => 'Okay',
    'okButtonLabel' => 'Okay',

    // text to display on secondary button. default is Cancel
    'cancel_button_label' => 'Cancel',
    'cancelButtonLabel' => 'Cancel',

    // action to perform when secondary button is clicked. default is close.
    // provide a custom js function as string to execute that function. example "saveUser"
    'ok_button_action' => 'close',
    'okButtonAction' => 'close',

    // action to perform when primary button is clicked. default is close.
    // provide a custom js function as a string to execute that function. example "confirmAction"
    'cancel_button_action' => 'close',
    'cancelButtonAction' => 'close',

    // close modal when either primary or close secondary buttons are clicked
    // the modal will be closed after your custom js function has been executed
    'close_after_action' => true,
    'closeAfterAction' => true,

    // determines if clicking on the backdrop can close the modal. default is true
    // when set to false, only the action buttons can close the modal.
    // in this case ensure you have set "close" as an action for one of your action buttons
    'backdrop_can_close' => true,
    'backdropCanClose' => true,

    // should the action buttons be displayed? default is true. false will hide the buttons
    'show_action_buttons' => true,
    'showActionButtons' => true,

    // should the action buttons be centered? default is false. right aligned
    'center_action_buttons' => false,
    'centerActionButtons' => false,

    // should the action buttons stretch the entire width of the modal
    'stretch_action_buttons' => false,
    'stretchActionButtons' => false,

    // should the backdrop of the modal be blurred
    'blur_backdrop' => true,
    'blurBackdrop' => true,

    // determines the size of the modal. available options are small, medium, large and xl
    // on mobile it is small by default but fills up the width of the screen
    'size' => 'big',
    'sizes' => [
        'tiny' => 'w-1/6',
        'small' => 'w-1/5',
        'medium' => 'w-1/4',
        'big' => 'w-1/3',
        'large' => 'w-2/5',
        'xl' => 'w-2/3',
        'omg' => 'w-11/12'
    ],

    // add extra css to the modal body
    'body_css' => '',
    // add extra css to the modal footer
    'footer_css' => '',
    // show close icon. By default, the close or cancel button closes the modal
    'show_close_icon' => false,
    'showCloseIcon' => false,
]); ?>
<?php foreach (array_filter(([
    // determines types of icon to display. Available options: info, success, error, warning
    // only the blank type (type='') has no icon. useful if you want your modal to contain a form
    // or other custom content
    'type' => '',

    // title text to display. example: Confirm your delete action
    'title' => '',

    // name of the modal. used to uniquely identify the modal in css and js
    'name' => 'bw-modal-'.uniqid(),

    // text to display on the primary button. default is Okay
    'ok_button_label' => 'Okay',
    'okButtonLabel' => 'Okay',

    // text to display on secondary button. default is Cancel
    'cancel_button_label' => 'Cancel',
    'cancelButtonLabel' => 'Cancel',

    // action to perform when secondary button is clicked. default is close.
    // provide a custom js function as string to execute that function. example "saveUser"
    'ok_button_action' => 'close',
    'okButtonAction' => 'close',

    // action to perform when primary button is clicked. default is close.
    // provide a custom js function as a string to execute that function. example "confirmAction"
    'cancel_button_action' => 'close',
    'cancelButtonAction' => 'close',

    // close modal when either primary or close secondary buttons are clicked
    // the modal will be closed after your custom js function has been executed
    'close_after_action' => true,
    'closeAfterAction' => true,

    // determines if clicking on the backdrop can close the modal. default is true
    // when set to false, only the action buttons can close the modal.
    // in this case ensure you have set "close" as an action for one of your action buttons
    'backdrop_can_close' => true,
    'backdropCanClose' => true,

    // should the action buttons be displayed? default is true. false will hide the buttons
    'show_action_buttons' => true,
    'showActionButtons' => true,

    // should the action buttons be centered? default is false. right aligned
    'center_action_buttons' => false,
    'centerActionButtons' => false,

    // should the action buttons stretch the entire width of the modal
    'stretch_action_buttons' => false,
    'stretchActionButtons' => false,

    // should the backdrop of the modal be blurred
    'blur_backdrop' => true,
    'blurBackdrop' => true,

    // determines the size of the modal. available options are small, medium, large and xl
    // on mobile it is small by default but fills up the width of the screen
    'size' => 'big',
    'sizes' => [
        'tiny' => 'w-1/6',
        'small' => 'w-1/5',
        'medium' => 'w-1/4',
        'big' => 'w-1/3',
        'large' => 'w-2/5',
        'xl' => 'w-2/3',
        'omg' => 'w-11/12'
    ],

    // add extra css to the modal body
    'body_css' => '',
    // add extra css to the modal footer
    'footer_css' => '',
    // show close icon. By default, the close or cancel button closes the modal
    'show_close_icon' => false,
    'showCloseIcon' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    if ($okButtonLabel !== $ok_button_label) $ok_button_label = $okButtonLabel;
    if ($okButtonAction !== $ok_button_action) $ok_button_action = $okButtonAction;
    if ($cancelButtonLabel !== $cancel_button_label) $cancel_button_label = $cancelButtonLabel;
    if ($cancelButtonAction !== $cancel_button_action) $cancel_button_action = $cancelButtonAction;

    $close_after_action = filter_var($close_after_action, FILTER_VALIDATE_BOOLEAN);
    $closeAfterAction = filter_var($closeAfterAction, FILTER_VALIDATE_BOOLEAN);
    $backdrop_can_close = filter_var($backdrop_can_close, FILTER_VALIDATE_BOOLEAN);
    $backdropCanClose = filter_var($backdropCanClose, FILTER_VALIDATE_BOOLEAN);
    $show_action_buttons = filter_var($show_action_buttons, FILTER_VALIDATE_BOOLEAN);
    $showActionButtons = filter_var($showActionButtons, FILTER_VALIDATE_BOOLEAN);
    $center_action_buttons = filter_var($center_action_buttons, FILTER_VALIDATE_BOOLEAN);
    $centerActionButtons = filter_var($centerActionButtons, FILTER_VALIDATE_BOOLEAN);
    $stretch_action_buttons = filter_var($stretch_action_buttons, FILTER_VALIDATE_BOOLEAN);
    $stretchActionButtons = filter_var($stretchActionButtons, FILTER_VALIDATE_BOOLEAN);
    $blur_backdrop = filter_var($blur_backdrop, FILTER_VALIDATE_BOOLEAN);
    $blurBackdrop = filter_var($blurBackdrop, FILTER_VALIDATE_BOOLEAN);
    $show_close_icon = filter_var($show_close_icon, FILTER_VALIDATE_BOOLEAN);
    $showCloseIcon = filter_var($showCloseIcon, FILTER_VALIDATE_BOOLEAN);

    if (!$closeAfterAction) $close_after_action = $closeAfterAction;
    if (!$backdropCanClose) $backdrop_can_close = $backdropCanClose;
    if (!$showActionButtons) $show_action_buttons = $showActionButtons;
    if ($centerActionButtons) $center_action_buttons = $centerActionButtons;
    if ($stretchActionButtons) $stretch_action_buttons = $stretchActionButtons;
    if ($blurBackdrop) $blur_backdrop = $blurBackdrop;
    if(!$showCloseIcon) $show_close_icon = $showCloseIcon;
    //-------------------------------------------------------------------

    $name = str_replace(' ', '-', $name);
    $cancelCss = ($cancel_button_label == '') ? 'hidden' : '';
    $okCss = ($ok_button_label == '') ? 'hidden' : '';
    $okAction = $cancelAction = "hideModal('{$name}')";
    if($ok_button_action !== 'close') $okAction = $ok_button_action . (($close_after_action) ? ';'.$okAction : '');
    if($cancel_button_action !== 'close') $cancelAction = $cancel_button_action . (($close_after_action) ? ';'.$cancelAction : '');
    $button_size = ($stretch_action_buttons) ? 'medium' : (($size == 'tiny') ? 'tiny' : 'small');
?>

<?php //this is intentional // required, so tailwindCSS will compile the styles in ?>
<span class="sm:w-1/6 sm:w-1/5 sm:w-1/4 sm:w-1/3 sm:w-2/5 sm:w-2/3 sm:w-11/12"></span>

<div data-name="<?php echo e($name); ?>" data-backdrop-can-close="<?php echo e($backdrop_can_close); ?>"
     class="w-full h-full bg-black/40 fixed left-0 top-0 <?php if($blur_backdrop): ?> backdrop-blur-md <?php endif; ?> z-40 flex bw-modal bw-<?php echo e($name); ?>-modal hidden">
    <div class="sm:<?php echo e($sizes[$size]); ?> w-full p-4 m-auto bw-<?php echo e($name); ?> animate__faster">
        <div class="bg-white  rounded-lg drop-shadow-2xl">
            <?php if( $show_action_buttons && $show_close_icon): ?>
                <a href="javascript:void(0)" onclick="<?php echo $cancelAction; ?>">
                    <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'x-mark','class' => 'text-gray-400 hover:bg-gray-200 hover:rounded-full p-1 absolute right-3 top-3 modal-close-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x-mark','class' => 'text-gray-400 hover:bg-gray-200 hover:rounded-full p-1 absolute right-3 top-3 modal-close-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
                </a>
            <?php endif; ?>
            <div class="<?php echo e((!empty($type))?'flex':'flex-initial'); ?>">
                <?php if(!empty($type)): ?>
                    <div class="modal-icon py-7 pl-5 grow-0">
                        <?php if (isset($component)) { $__componentOriginaldd9042d600e0aeb384f3deebb44f611b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal-icon','data' => ['type' => ''.e($type).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::modal-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => ''.e($type).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $attributes = $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $component = $__componentOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
                <div class="modal-body grow p-7 <?php if(!empty($type)): ?> !pl-3 <?php endif; ?> <?php echo e($body_css); ?>">
                    <h1 class="text-[22px] font-bold text-slate-900/80 modal-title text-left"><?php echo e($title); ?></h1>
                    <div class="modal-text text-gray-600 pt-2 text-base leading-6 tracking-wide text-left">
                        <?php echo e($slot); ?>

                    </div>
                </div>
            </div>
            <?php if( $show_action_buttons ): ?>
                <div class="modal-footer <?php if($stretch_action_buttons): ?> flex flex-col-reverse <?php endif; ?> <?php if($center_action_buttons || in_array($size, ['tiny', 'small', 'medium'])): ?> text-center <?php else: ?> text-right <?php endif; ?> bg-gray-100 border-t border-t-gray-200/60 py-3 px-6 rounded-br-lg rounded-bl-lg <?php echo e($footer_css); ?>">
                    <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => ['type' => 'secondary','size' => ''.e($button_size).'','onclick' => ''.$cancelAction.'','class' => 'cancel '.e((($stretch_action_buttons) ? 'block w-full mb-3' : '')).' '.e($cancelCss).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'secondary','size' => ''.e($button_size).'','onclick' => ''.$cancelAction.'','class' => 'cancel '.e((($stretch_action_buttons) ? 'block w-full mb-3' : '')).' '.e($cancelCss).'']); ?><?php echo e($cancel_button_label); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => ['size' => ''.e($button_size).'','onclick' => ''.$okAction.'','class' => 'okay '.e((($stretch_action_buttons) ? 'block w-full mb-3 !ml-0' : 'ml-3')).' '.e($okCss).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => ''.e($button_size).'','onclick' => ''.$okAction.'','class' => 'okay '.e((($stretch_action_buttons) ? 'block w-full mb-3 !ml-0' : 'ml-3')).' '.e($okCss).'']); ?><?php echo e($ok_button_label); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<span class="overflow-hidden"></span>

<script>
    dom_el('.bw-<?php echo e($name); ?>-modal').addEventListener('click', function (e) {
        let backdrop_can_close = this.getAttribute('data-backdrop-can-close');
        if (backdrop_can_close) hideModal('<?php echo e($name); ?>');
    });

    dom_el('.bw-<?php echo e($name); ?>').addEventListener('click', function (e) {
        e.stopImmediatePropagation();
    });

    if (dom_els('.bw-<?php echo e($name); ?>-modal .modal-footer>button')) {
        dom_els('.bw-<?php echo e($name); ?>-modal .modal-footer>button').forEach((el) => {
            el.addEventListener('click', function (e) {
                e.stopImmediatePropagation();
            });
        });
    }

    document.addEventListener('keyup', function (e) {
        if (e.key === "Escape") {
            if (current_modal !== undefined && current_modal.length > 0) {
                let modal_name = current_modal[(current_modal.length - 1)];
                if (dom_el(`.bw-${modal_name}-modal`).getAttribute('data-backdrop-can-close') === '1') {
                    hideModal(modal_name);
                    e.stopImmediatePropagation();
                }
            }
        }
    })

    document.addEventListener('keydown', trapFocusInModal);

</script>
<?php /**PATH /var/www/game.local/resources/views/components/bladewind/modal.blade.php ENDPATH**/ ?>