<?php if($weapons->count()): ?>
    <div class="mt-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-2">Weapons:</h3>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <?php $__currentLoopData = $weapons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weapon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border rounded-lg shadow p-4 bg-white">
                    <div class="flex flex-row pb-1">
                        <h4 class="text-md font-bold text-gray-900 m-1"><?php echo e($weapon->name); ?></h4>
                        <?php if (isset($component)) { $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02 = $attributes; } ?>
<?php $component = App\View\Components\Rename::resolve(['type' => 'weapon','id' => ''.e($weapon->id).'','name' => ''.e($weapon->name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rename'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Rename::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $attributes = $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $component = $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
                    </div>
                    <p class="text-sm text-gray-700"><span class="font-semibold">DMG:</span> <?php echo e($weapon->damage); ?></p>
                    <p class="text-sm text-gray-700"><span class="font-semibold">Type:</span> <?php echo e($weapon->type); ?></p>
                    <p class="text-sm text-gray-700"><span class="font-semibold">Level:</span> <?php echo e($weapon->lvl); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/game.local/resources/views/components/weapon-list.blade.php ENDPATH**/ ?>