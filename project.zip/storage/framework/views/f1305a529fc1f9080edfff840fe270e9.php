<?php if (isset($component)) { $__componentOriginald73677f70f563e9b0db6070e9aea6576 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald73677f70f563e9b0db6070e9aea6576 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-group','data' => ['name' => 'weapons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'weapons']); ?>
     <?php $__env->slot('headings', null, []); ?> 
        <?php $__currentLoopData = $player->train->wagons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($wagon->wagonable instanceof \App\Models\WeaponWagon && $wagon->wagonable->weapons): ?>
                <?php $__currentLoopData = $wagon->wagonable->weapons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weapon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-heading','data' => ['name' => 'weapon'.e($weapon->id).'','label' => ''.e($weapon->name.' - '.$wagon->name).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'weapon'.e($weapon->id).'','label' => ''.e($weapon->name.' - '.$wagon->name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $attributes = $__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__attributesOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25)): ?>
<?php $component = $__componentOriginal099f863fcedf7a504a1a10aef2a9bb25; ?>
<?php unset($__componentOriginal099f863fcedf7a504a1a10aef2a9bb25); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginalb705a984512d26a5581848182038e9df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb705a984512d26a5581848182038e9df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-body','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php $__currentLoopData = $player->train->wagons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wagon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($wagon->wagonable instanceof \App\Models\WeaponWagon && $wagon->wagonable->weapons): ?>
                <?php $__currentLoopData = $wagon->wagonable->weapons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weapon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'weapon'.e($weapon->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'weapon'.e($weapon->id).'']); ?>
                        <div class="p-6 flex-col">
                            <p class="mt-4 text-lg text-gray-900">Name:             <?php echo e($weapon->name); ?></p>
                            <p class="mt-4 text-lg text-gray-900">Level:            <?php echo e($weapon->lvl); ?>(+1)</p>
                            <p class="mt-4 text-lg text-gray-900">Damage:           <?php echo e($weapon->damage); ?> (+<?php echo e(50 * ($weapon->lvl+1)); ?>)</p>
                            <p class="mt-4 text-lg text-gray-900">Upgrade Cost:     <?php echo e($weapon->upgrade_cost); ?></p>

                            <form method="POST" action="<?php echo e(route('weapon.upgrade', $weapon)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="mt-4 space-x-2">
                                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('Upgrade')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                                </div>
                            </form>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $attributes = $__attributesOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__attributesOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb705a984512d26a5581848182038e9df)): ?>
<?php $component = $__componentOriginalb705a984512d26a5581848182038e9df; ?>
<?php unset($__componentOriginalb705a984512d26a5581848182038e9df); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $attributes = $__attributesOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__attributesOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald73677f70f563e9b0db6070e9aea6576)): ?>
<?php $component = $__componentOriginald73677f70f563e9b0db6070e9aea6576; ?>
<?php unset($__componentOriginald73677f70f563e9b0db6070e9aea6576); ?>
<?php endif; ?>

<?php /**PATH /var/www/game.local/resources/views/town/partials/upgrade/weapons.blade.php ENDPATH**/ ?>