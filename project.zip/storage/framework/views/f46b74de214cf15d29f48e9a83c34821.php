<p class="mt-4 text-lg text-gray-900">Workshop: <?php echo e(($town->workshop ? 'Present' : 'Absent')); ?></p>
<p class="mt-4 text-lg text-gray-900">Rail Shop: <?php echo e(($town->rail_shop ? 'Present' : 'Absent')); ?></p>
<p class="mt-4 text-lg text-gray-900">Resource Shop: <?php echo e(($town->shop ? 'Present' : 'Absent')); ?></p>
<p class="mt-4 text-lg text-gray-900">Saloon: <?php echo e(($town->saloon ? 'Present' : 'Absent')); ?></p>
<?php /**PATH /var/www/game.local/resources/views/town/partials/town-info.blade.php ENDPATH**/ ?>