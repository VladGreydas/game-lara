<section>
    <?php if (isset($component)) { $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bladewind.tab-content','data' => ['name' => 'weapon-'.e($weapon->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind.tab-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'weapon-'.e($weapon->id).'']); ?>
        <div class="p-6 ml-5 flex-col">
            <h3 class="p-5 font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e($weapon->name); ?>

            </h3>
            <div class="p-6 flex-col">
                <div class="flex">
                    <p class="pt-2 pr-2 text-lg text-gray-900">Name: <?php echo e($weapon->name); ?></p>
                    <?php if (isset($component)) { $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02 = $attributes; } ?>
<?php $component = App\View\Components\Rename::resolve(['name' => 'weapon','id' => ''.e($weapon->id).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rename'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Rename::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $attributes = $__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__attributesOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02)): ?>
<?php $component = $__componentOriginala832fe8e222e0af2702f2ec3f41c4e02; ?>
<?php unset($__componentOriginala832fe8e222e0af2702f2ec3f41c4e02); ?>
<?php endif; ?>
                </div>
                <p class="mt-4 text-lg text-gray-900">Level: <?php echo e($weapon->lvl); ?></p>
                <p class="mt-4 text-lg text-gray-900">Damage: <?php echo e($weapon->damage); ?></p>
                <p class="mt-4 text-lg text-gray-900">Type: <?php echo e($weapon->type); ?></p>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $attributes = $__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__attributesOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9)): ?>
<?php $component = $__componentOriginal6584a7831d9ac857c282e0bb699f3ba9; ?>
<?php unset($__componentOriginal6584a7831d9ac857c282e0bb699f3ba9); ?>
<?php endif; ?>
</section>
<?php /**PATH /var/www/game.local/resources/views/player/partials/weapon-info.blade.php ENDPATH**/ ?>